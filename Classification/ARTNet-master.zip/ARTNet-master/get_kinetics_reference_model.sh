#!/usr/bin/env sh

wget -O 112_c3d_resnet_18_kinetics.caffemodel http://people.ee.ethz.ch/~limwang/artnet_model/112_c3d_resnet_18_kinetics.caffemodel
wget -O 112_artnet_resnet_18_kinetics.caffemodel http://people.ee.ethz.ch/~limwang/artnet_model/112_artnet_resnet_18_kinetics.caffemodel
wget -O 112_artnet_tsn_resnet_18_kinetics.caffemodel http://people.ee.ethz.ch/~limwang/artnet_model/112_artnet_tsn_resnet_18_kinetics.caffemodel






VideoFeatures
yndk@sogang.ac.kr
=============

Video Feature Detectors/Descriptors working on Mac OS X
Gathered on the web.
function parsave(fname, x,y,w,z)
	save(fname, 'x', 'y','w','z','-v7.3')
end

% Segmentation CAscades with Localized Priors and Efficient Learning
% Version 1 04-23-2013
%
% By David Weiss & Ben Taskar. See scalpel_demo.m for information on how 
% to use the toolbox.
%
% SCALPEL Setup
%   SCALPEL.config     - Set up where output, working files should go
%
% SCALPEL Demo
%   scalpel_demo.m     - Demo instructions
%   startup.m          - Paths setup (should work automatically)


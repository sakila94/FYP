function [tax] = get_tree_taxonomy(tree)

% ======================================================================
% Copyright (c) 2012 David Weiss
% 
% Permission is hereby granted, free of charge, to any person obtaining
% a copy of this software and associated documentation files (the
% "Software"), to deal in the Software without restriction, including
% without limitation the rights to use, copy, modify, merge, publish,
% distribute, sublicense, and/or sell copies of the Software, and to
% permit persons to whom the Software is furnished to do so, subject to
% the following conditions:
% 
% The above copyright notice and this permission notice shall be
% included in all copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
% EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
% MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
% NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
% LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
% OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
% WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
% ======================================================================

for d = 2:tree.depth
    tax{d-1}=  get_tree_taxonomy_r(tree, d);
end

function tax = get_tree_taxonomy_r(tree, D, d, tax)

if nargin==2
    d = 1; tax = cell(tree.maxid(D-1), 1);
end

if (d == D-1)
    for i = 1:numel(tree.sub)
        tax{tree.id(i)} = tree.sub(i).id;
    end
else
    for i = 1:numel(tree.sub)
        tax = get_tree_taxonomy_r(tree.sub(i), D, d+1, tax);
    end
end


    


